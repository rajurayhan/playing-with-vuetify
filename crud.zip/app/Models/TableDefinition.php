<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TableDefinition extends Model
{
    protected $guarded = [];

    protected $table = 'm_table_definitions';
}
